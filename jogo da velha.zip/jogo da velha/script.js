const COMBINACOES_VITORIA = [
    [0,3,6], [1,4,7],[2,5,8], //coluna
    [0,1,2],[3,4,5],[6,7,8], //linha
    [0,4,8],[2,4,6] //diagonal
];

const CHAVE_LOCAL_STOREGE = "jogo-da-velha";

//nome dos jogadores
const nomeX = document.getElementById("nome-x");
const nomeO = document.getElementById("nome-o");

//placar do jogo
const placarNomeX = document.getElementById("placar-nome-x");
const placarNomeO = document.getElementById("placar-nome-o");

const placarX = document.getElementById("placar-x");
const placarO = document.getElementById("placar-o");
const placarEmpate = document.getElementById("placar-empate");